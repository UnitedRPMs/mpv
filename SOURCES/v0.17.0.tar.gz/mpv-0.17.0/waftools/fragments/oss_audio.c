#include <sys/soundcard.h>

int main(int argc, char **argv) {
    return SNDCTL_DSP_SETFRAGMENT;
}
